package com.android.us.model

import android.databinding.BaseObservable
import android.text.TextUtils
import android.util.Patterns
import java.util.regex.Pattern

class Login(private var email: String, private var password: String) : BaseObservable() {
    val isDataValidation: Boolean
        get() = (TextUtils.isEmpty(getEmail()))
                && Patterns.EMAIL_ADDRESS.matcher(getEmail()).matches()
                && getPassword().length > 5

    private fun getEmail(): String {
        return email
    }

    private fun getPassword(): String {

        return password
    }

    fun setEmail(email: String) {
        this.email = email
    }

    fun setPassword(password: String) {
        this.password = password
    }
}