package com.android.us.Interfacce

interface LoginResultCallBack {
    fun onSuccess(message:String)
    fun onFailure(message:String)
}