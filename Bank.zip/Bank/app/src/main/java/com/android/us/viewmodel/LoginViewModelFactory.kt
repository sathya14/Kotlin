package com.android.us.viewmodel

import android.arch.lifecycle.ViewModel
import android.arch.lifecycle.ViewModelProvider
import com.android.us.Interfacce.LoginResultCallBack
import javax.sql.RowSetListener

class LoginViewModelFactory(private val listener: LoginResultCallBack) : ViewModelProvider.NewInstanceFactory() {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return LoginViewModel(listener) as T
    }

}